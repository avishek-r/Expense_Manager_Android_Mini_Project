package com.example.miniproject.view;

public interface AddCategoryView {
    String getCategory();

    void displayError();
}
